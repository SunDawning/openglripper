﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

public class StreamDataBuff
{
    public StreamDataBuff(byte[] data)
    {
        memoryStream = new MemoryStream();
        memoryStream.Write(data, 0, (int)data.Length);
        memoryStream.Seek(0, SeekOrigin.Begin);
    }
    public MemoryStream memoryStream;
    public void Read(out Vector3 value)
    {
        Vector3 vector3 = new Vector3();
        Read(out vector3.x);
        Read(out vector3.y);
        Read(out vector3.z);

        value = vector3;
    }

    public bool CanRead(UInt32 length = 0)
    {
        return memoryStream.Position + length <= memoryStream.Length;
    }
    
    public void Read(out UInt32 value)
    {
        value = BitConverter.ToUInt32(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(UInt32);
    }

    public void Skip(UInt32 offset)
    {
        memoryStream.Position += offset;
    }

    public void Read(out UInt64 value)
    {
        value = BitConverter.ToUInt64(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(UInt64);
    }

    public void Read(out Int32 value)
    {
        value = BitConverter.ToInt32(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(Int32);
    }

    public void Read(out Int64 value)
    {
        value = BitConverter.ToInt64(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(Int64);
    }

    public void Read(out float value)
    {
        value = BitConverter.ToSingle(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(float);
    }

    public void Read(out UInt16 value)
    {
        value = BitConverter.ToUInt16(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(UInt16);
    }

    public void Read(out Int16 value)
    {
        value = BitConverter.ToInt16(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(Int16);
    }

    public void Read(out bool value)
    {
        value = BitConverter.ToBoolean(memoryStream.GetBuffer(), (int)memoryStream.Position);
        memoryStream.Position += sizeof(bool);
    }

    public void Read(out byte value)
    {
        value = memoryStream.GetBuffer()[(int)memoryStream.Position];
        memoryStream.Position += sizeof(byte);
    }

    public void Read(out string value)
    {
        UInt16 size;
        Read(out size);
        value = System.Text.UTF8Encoding.UTF8.GetString(memoryStream.GetBuffer(), (int)memoryStream.Position, size);//ascii to utf8
        memoryStream.Position += size;
    }
}
