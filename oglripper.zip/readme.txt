1.首先用InjInjector 启动或者附加需要ripper的进程
Injector.exe [Pid|ExePath]

2. 启动完毕后在命令窗口输入dump,就会dump当前场景的模型，贴图，shader。