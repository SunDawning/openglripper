﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using UnityEditor;
public struct VertexAttrib
{
    public UInt32       _indx;
    public Int32        _size;
    public UInt32       _type;
    public byte         _normalized;
    public UInt32        _stride;
    public UInt32       _offset;

    public void Read(StreamDataBuff dataBuff)
    {
        dataBuff.Read(out _indx);
        dataBuff.Read(out _size);
        dataBuff.Read(out _type);
        dataBuff.Read(out _normalized);
        dataBuff.Read(out _stride);
        dataBuff.Read(out _offset);
    }
}

public struct IndxAttrib
{
    public UInt32 _mode;
    public Int32  _count;
    public UInt32 _type;
    public UInt32 _offset;

    public void Read(StreamDataBuff dataBuff)
    {
        dataBuff.Read(out _mode);
        dataBuff.Read(out _count);
        dataBuff.Read(out _type);
        dataBuff.Read(out _offset);
    }
}

public class ModeLoad : MonoBehaviour {

    public MeshFilter   m_meshFilter;
    public string       m_modeFile;
    public string       m_IndexFile;
    public string       m_uvFile;
    public string       m_texFile;
    public bool         m_bFlipUV = false;
    public bool         m_bFlipXY = false;

    enum GLDataType
    {
        GL_BYTE             = 0x1400,
        GL_UNSIGNED_BYTE    = 0x1401,
        GL_SHORT            = 0x1402,
        GL_UNSIGNED_SHORT   = 0x1403,
        GL_INT              = 0x1404,
        GL_UNSIGNED_INT     = 0x1405,
        GL_FLOAT            = 0x1406,
        GL_FIXED            = 0x140C
    };
    static UInt32 GetSizeFromGLType(UInt32 type)
    {
        switch ((GLDataType)type)
        {
            case GLDataType.GL_BYTE:
                return 1;
            case GLDataType.GL_UNSIGNED_BYTE:
                return 1;
            case GLDataType.GL_SHORT:
                return 2;
            case GLDataType.GL_UNSIGNED_SHORT:
                return 2;
            case GLDataType.GL_INT:
                return 4;
            case GLDataType.GL_UNSIGNED_INT:
                return 4;
            case GLDataType.GL_FLOAT:
                return 4;
            case GLDataType.GL_FIXED:
                return 4;
            default:
                break;
        }
        return 0;
    }
    static void ReadFormat(GLDataType type, StreamDataBuff buff, ref object obj)
    {
        switch (type)
        {
            case GLDataType.GL_UNSIGNED_BYTE:
            case GLDataType.GL_BYTE:
                {
                    byte d;
                    buff.Read(out d);
                    obj = d;
                    break;
                }
            case GLDataType.GL_SHORT:
                {
                    short d;
                    buff.Read(out d);
                    obj = d;
                    break;
                }
            case GLDataType.GL_UNSIGNED_SHORT:
                {
                    ushort d;
                    buff.Read(out d);
                    obj = d;
                    break;
                }
            case GLDataType.GL_FIXED:
            case GLDataType.GL_INT:
                {
                    Int32 d;
                    buff.Read(out d);
                    obj = d;
                    break;
                }
            case GLDataType.GL_UNSIGNED_INT:
                {
                    UInt32 d;
                    buff.Read(out d);
                    obj = d;
                    break;
                }
            case GLDataType.GL_FLOAT:
                {
                    float d;
                    buff.Read(out d);
                    obj = d;
                    break;
                }
            default:
                Debug.Log("not support format:" + type.ToString());
                return;
                break;
        }
    }

    static public Mesh CreateMesh(string modeFile, string indxFile, string uvFile, bool flipUv, bool flipXY)
    {
        string dumpDir = "Assets/Resources/gldump/";
        byte[] byteVert = File.Exists(dumpDir + modeFile) ? File.ReadAllBytes(dumpDir + modeFile) : null;
        List<Vector3> vertList = new List<Vector3>();
        if (byteVert != null)
        {
            StreamDataBuff vertDataBuff = new StreamDataBuff(byteVert);
            VertexAttrib vertAttrib = new VertexAttrib();
            vertAttrib.Read(vertDataBuff);            
            UInt32 needCount = vertAttrib._stride == 0 ? (GetSizeFromGLType(vertAttrib._type) * (UInt32)vertAttrib._size) : vertAttrib._stride;
            vertDataBuff.memoryStream.Position += vertAttrib._offset;
            UInt32 vCount = (UInt32)vertAttrib._size * GetSizeFromGLType(vertAttrib._type);
            while (vertDataBuff.CanRead(vCount))
            {
                long pos = vertDataBuff.memoryStream.Position;
                Vector3 v = new Vector3();
                Int32 vIdx = 0;
                for (int i = 0; i < vertAttrib._size && vIdx < 3; ++i)
                {
                    object d = new object();
                    ReadFormat((GLDataType)vertAttrib._type, vertDataBuff, ref d);
                    float f = Convert.ToSingle(d);
                    if(!float.IsNaN(f) && !float.IsNegativeInfinity(f) && !float.IsPositiveInfinity(f) && (Mathf.Abs(f) < UInt32.MaxValue))
                    {
                        v[vIdx++] = Convert.ToSingle(d);
                    }
                    else
                    {

                        Debug.Log("NaN:" + (vertList.Count * 3 + vIdx));
                        v[vIdx++] = 0;
                    }
                }
                vertDataBuff.memoryStream.Position = pos + needCount;
                vertList.Add(v);
            }
        }
        else
        {
            Debug.Log(dumpDir + modeFile + " error");
            return null;
        }
        
        byte[] bytesUv = File.Exists(dumpDir + uvFile) ? File.ReadAllBytes(dumpDir + uvFile) : null;
        List<Vector2> uvList = new List<Vector2>();
        if (bytesUv != null)
        {
            StreamDataBuff uvDataBuff = new StreamDataBuff(bytesUv);
            VertexAttrib vertAttribUv = new VertexAttrib();
            vertAttribUv.Read(uvDataBuff);            
            UInt32 needCount = vertAttribUv._stride == 0 ? (GetSizeFromGLType(vertAttribUv._type) * (UInt32)vertAttribUv._size) : vertAttribUv._stride;
            uvDataBuff.memoryStream.Position += vertAttribUv._offset;
            UInt32 vCount = (UInt32)vertAttribUv._size * GetSizeFromGLType(vertAttribUv._type);
            while (uvDataBuff.CanRead(vCount))
            {
                long pos = uvDataBuff.memoryStream.Position;
                Vector2 v = new Vector2();
                Int32 vIdx = 0;
                for (int i = 0; i < vertAttribUv._size && vIdx < 2; ++i)
                {
                    object d = new object();
                    ReadFormat((GLDataType)GLDataType.GL_FLOAT, uvDataBuff, ref d);
                    v[vIdx] = Convert.ToSingle(d);
                    if (flipUv)
                    {
                        if (vIdx == 1)
                        {
                            v[vIdx] = 1 - v[vIdx];
                        }
                    }
                    vIdx++;
                }
                uvDataBuff.memoryStream.Position = pos + needCount;
                uvList.Add(v);
            }
        }
        else
        {
            Debug.Log(dumpDir + uvFile + " error");
        }
        

        for (; uvList.Count < vertList.Count;)
        {
            uvList.Add(new Vector2(0, 0));
        }

        for (; vertList.Count < uvList.Count;)
        {
            vertList.Add(new Vector3(0, 0, 0));
        }
        byte[] byteIndx = File.Exists(dumpDir + indxFile) ? File.ReadAllBytes(dumpDir + indxFile) : null;
        List<int> idxList = new List<int>();
        if (byteIndx != null)
        {
            StreamDataBuff indxDataBuff = new StreamDataBuff(byteIndx);
            IndxAttrib indxAttrib = new IndxAttrib();
            indxAttrib.Read(indxDataBuff);
            UInt32 needCountidx = GetSizeFromGLType(indxAttrib._type);
            while (indxDataBuff.CanRead(needCountidx))
            {
                object d = new object();
                ReadFormat((GLDataType)indxAttrib._type, indxDataBuff, ref d);
                idxList.Add(Convert.ToInt32(d));
            }

        }
        else
        {
            Debug.Log(dumpDir + indxFile + " error");
            return null;
        }
        
        //flip A,B
        if (flipXY)
        {
            for (int i = 0; i < idxList.Count; i += 3)
            {
                int v = idxList[i];
                idxList[i] = idxList[i + 1];
                idxList[i + 1] = v;
            }
        }
        Mesh ret = new Mesh();
        ret.vertices = vertList.ToArray();
        ret.uv = uvList.ToArray();
        ret.triangles = idxList.ToArray();
        ret.RecalculateNormals();
        ret.RecalculateBounds();
        return ret;
    }

    [ContextMenu("Refresh")]
    public void Init()
    {
        m_meshFilter.sharedMesh = CreateMesh(m_modeFile, m_IndexFile, m_uvFile, m_bFlipUV, m_bFlipXY);
        string dumpDir = "Assets/Resources/gldump/";
        MeshRenderer meshRender = GetComponent<MeshRenderer>();
        if(meshRender != null)
        {            
            if(File.Exists(dumpDir + m_texFile))
            {
                Material mat = new Material(Shader.Find("Standard"));
                string file = Path.GetDirectoryName("gldump/" + m_texFile) + "/" + Path.GetFileNameWithoutExtension(m_texFile);
                UnityEngine.Object obj = Resources.Load(file);
                Texture2D tex = obj as Texture2D;
                mat.SetTexture("_MainTex", tex);
                meshRender.material = mat;
            }
        }
    }
    void Start ()
    {
        //Init();
    }

}
